<div align="center">

# 🇮🇳 BharatRank

### Multi-Signal Agentic Candidate Intelligence Engine

*Built for The India Runs Hackathon by Redrob AI — Data & AI Track*

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-green.svg)](https://fastapi.tiangolo.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

</div>

---

## The Problem

India produces 1.5 million engineering graduates per year. Traditional ATS systems filter them using keyword matching — a system built for Silicon Valley that systematically buries great talent from tier-2 colleges, tier-2 cities, and non-linear career paths.

**A candidate from VJTI with 380 GitHub commits/year and 3 AI certifications loses to a candidate from IIT who hasn't touched code in 2 years. That's not intelligence. That's bias.**

---

## What BharatRank Does

BharatRank is a **multi-signal, agentic candidate ranking engine** that replaces keyword matching with genuine intelligence:

```
Job Description  +  Candidate Profiles
         ↓
  [LLM JD Agent]  ← Gemini 1.5 Flash deconstructs hidden intent
         ↓
  [Multilingual Embedder + FAISS]  ← paraphrase-multilingual-mpnet
         ↓
  [Multi-Signal Scorer]  ← 5 weighted signals
         ↓
  [India-First Normalizer]  ← anti-bias, Hidden Gem detector
         ↓
  [Explainability Engine]  ← human-readable match reports
         ↓
   Ranked Candidates + Match Reports
```

---

## BharatScore Formula

```
BharatScore = 0.35 × SemanticFit
            + 0.20 × CareerVelocity
            + 0.20 × SkillRecency
            + 0.15 × SignalStrength
            + 0.10 × RoleAlignment
```

| Signal | Weight | What it measures |
|---|---|---|
| **Semantic Fit** | 35% | FAISS cosine similarity — JD intent vs candidate profile |
| **Career Velocity** | 20% | Growth speed: roles advanced per year of experience |
| **Skill Recency** | 20% | Are skills current? Decay function by acquisition year |
| **Signal Strength** | 15% | GitHub commits + OSS contributions + certifications + hackathons |
| **Role Alignment** | 10% | Career arc — does the trajectory point toward this role? |

---

## India-First Features

### 💎 Hidden Gem Detector
Surfaces candidates from non-premier institutions who are systematically buried by keyword filters, but have strong measurable signals (GitHub activity, certifications, hackathon wins, high CGPA).

### ⚖️ Anti-Pedigree Bias Engine
Institution tier is used for **context only** — never for scoring. A small fairness boost (max +3%) is applied to Hidden Gems based on their signal strength.

### 🌐 Multilingual Embeddings
Uses `paraphrase-multilingual-mpnet-base-v2` — handles Indian-language terms, transliterations, and regional naming conventions in the same embedding space as English JDs.

### 📋 Career Gap Normalisation
Understands Indian-specific career patterns: startup failures, family responsibilities, board exam preparation years. These are flagged as *explainable* — never penalised.

### 🤖 LLM JD Agent
Gemini 1.5 Flash deconstructs vague JDs:
- `"rockstar developer"` → concrete technical requirements
- `"fast-paced startup"` → delivery velocity, ownership signals
- `"cross-functional"` → collaboration signals in OSS/project history

---

## Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/ChandanLabs/bharatrank
cd bharatrank
pip install -r requirements.txt
```

### 2. Configure (Optional — works without API key)

```bash
cp .env.example .env
# Add your Gemini API key for LLM-powered features
# Get it free at: https://aistudio.google.com/app/apikey
```

### 3. Run the CLI Demo

```bash
# Demo all 3 job descriptions
python demo.py --save

# Demo a specific JD, top 5 candidates
python demo.py --jd JD001 --top-k 5 --save
```

### 4. Start the API Server

```bash
uvicorn api.main:app --reload --port 8000
# API docs: http://localhost:8000/docs
```

### 5. Or use Docker

```bash
docker-compose up --build
```

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | System health + readiness |
| `POST` | `/rank` | Rank candidates for a JD |
| `GET` | `/rank/{jd_id}` | Quick ranking by JD ID |
| `GET` | `/rank-all` | Rank across all JDs |
| `GET` | `/candidates` | List all candidate profiles |
| `GET` | `/jds` | List all job descriptions |
| `GET` | `/docs` | Interactive OpenAPI docs |

### Example Request

```bash
curl -X POST http://localhost:8000/rank \
  -H "Content-Type: application/json" \
  -d '{"jd_id": "JD001", "top_k": 10}'
```

### Example Response (single candidate)

```json
{
  "rank": 1,
  "candidate_name": "Priya Nair",
  "location": "Pune, Maharashtra",
  "institution": "VJTI Mumbai",
  "adjusted_score": 0.8471,
  "signals": {
    "semantic_fit": 0.9123,
    "career_velocity": 0.6667,
    "skill_recency": 0.8800,
    "signal_strength": 0.7750,
    "role_alignment": 0.6400
  },
  "is_hidden_gem": true,
  "hidden_gem_reason": "Strong signals (380 GitHub commits/year, 3 certifications, 2 hackathon wins) from VJTI Mumbai — often filtered by keyword/brand-name ATS systems.",
  "top_skills": ["LangChain", "RAG", "PyTorch", "FastAPI", "NLP"],
  "match_report": "Priya Nair ranks #1 with strong semantic alignment and a highly current skill set. Currently building RAG and agentic systems at Sigmoid Analytics, with 15 OSS contributions and 2 hackathon wins signalling high initiative..."
}
```

---

## Run Tests

```bash
pytest tests/ -v
```

---

## Project Structure

```
bharatrank/
├── core/
│   ├── config.py          # Weights, thresholds, constants
│   ├── embedder.py        # SentenceTransformer + FAISS
│   ├── scorer.py          # 5-signal BharatScore engine
│   ├── jd_agent.py        # Gemini LLM JD deconstruction
│   ├── normalizer.py      # India-first normalisation + anti-bias
│   ├── explainer.py       # Human-readable match reports
│   └── ranker.py          # Main pipeline orchestrator
├── api/
│   ├── main.py            # FastAPI application
│   └── schemas.py         # Pydantic request/response models
├── data/
│   ├── candidates.json    # 20 Indian candidate profiles
│   └── job_descriptions.json  # 3 realistic JDs
├── tests/
│   ├── test_scorer.py     # Unit tests for scoring engine
│   └── test_normalizer.py # Unit tests for normalizer
├── output/                # Generated ranked output files
├── demo.py                # CLI demo with rich terminal output
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Semantic Embedding | `sentence-transformers/paraphrase-multilingual-mpnet-base-v2` |
| Vector Index | FAISS (IndexFlatIP — cosine similarity) |
| LLM Agent | Google Gemini 1.5 Flash |
| API Framework | FastAPI + Uvicorn |
| Data Validation | Pydantic v2 |
| Configuration | python-dotenv |
| Testing | pytest |
| Containerisation | Docker + docker-compose |

---

## Author

**Chandan Kumar Sah Teli**  
B.Tech CSE, Aditya University (2027)  
GitHub: [@ChandanLabs](https://github.com/ChandanLabs)

---

*Built for The India Runs Hackathon by Redrob AI — June 2026*
